# Description

A very old FreeBSD rootkit for the 1337 h4x0rs out there. This was my first
attempt to code in FreeBSD kernel land. So beare with me. :)
This version should work for at least for FreeBSD 7 and 8.

# Usage

```
Blah read code.
```

# Installation

Run `install.sh`.

# Author

noptrix

# Notes

- quick'n'dirty code
- My master-branches are always dev-branches; use releases for stable versions.
- All of my public stuff you find are officially announced and published via [nullsecurity.net](https://www.nullsecurity.net).

# License

Check docs/LICENSE.

# Disclaimer
We hereby emphasize, that the hacking related stuff found on
[nullsecurity.net](http://nullsecurity.net/) are only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
