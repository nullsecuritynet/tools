# Authors

* **Victor Dorneanu** (lead developer)
    + Twitter: [@victordorneanu](http://twitter.com/victordorneanu)
    + Web: [dornea.nu](http://dornea.nu)
    + GitHub: [github.com/dorneanu](http://github.com/dorneanu)
    + Xing: [xing.to/dorneanu](http://xing.to/dorneanu)

## Special Thanks To

* [nullsecurity](http://nullsecurity.net) - Hack the planet!
* [Levon 'noptrix' Kayan](http://twitter.com/noptrix) - Thanks for the good food! :)
* [Robert Schlenz](https://github.com/uniquehellfish) - Thanks for the D3 inspiration.