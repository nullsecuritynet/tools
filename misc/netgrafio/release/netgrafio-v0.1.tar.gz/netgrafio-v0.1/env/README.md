This is the folder where virtualenv will place its folders.
