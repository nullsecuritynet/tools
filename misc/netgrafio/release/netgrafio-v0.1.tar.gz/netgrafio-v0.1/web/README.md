This folder contains all web specific files (used within Flask) and the modules.
