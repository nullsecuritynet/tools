Here you could define your models, contants, views whatever.
