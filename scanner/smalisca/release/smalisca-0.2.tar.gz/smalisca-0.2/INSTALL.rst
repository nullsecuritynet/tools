==================
Installation
==================

Refer to the `installation page <http://smalisca.readthedocs.org/en/latest/installation.html>`_.
