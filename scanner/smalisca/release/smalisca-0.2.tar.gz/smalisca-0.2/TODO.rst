==========
TODO
==========

* modules/module_smali_parser:

    * Consider Windows paths
    * [DONE] multithreading for parsing operations

* analysis

    * Export results as HTML/D3-Graph
    * Allow regex patterns for search commands
    * ncurses interface(?)

* drawing

    * Improve layout of call graphs
    * Load configuration/settings from file
